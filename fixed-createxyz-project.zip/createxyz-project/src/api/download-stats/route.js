async function handler({ userId } = {}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  try {
    if (userId) {
      const stats = await sql`
        SELECT 
          COUNT(*) as total_downloads,
          COUNT(CASE WHEN completed = true THEN 1 END) as completed_downloads,
          COUNT(DISTINCT user_id) as unique_users,
          version,
          get_chat_date(download_timestamp) as download_date
        FROM downloads
        WHERE user_id = ${userId}
        GROUP BY version, get_chat_date(download_timestamp)
        ORDER BY download_date DESC
      `;
      return { success: true, stats };
    }

    const stats = await sql`
      SELECT 
        COUNT(*) as total_downloads,
        COUNT(CASE WHEN completed = true THEN 1 END) as completed_downloads,
        COUNT(DISTINCT user_id) as unique_users,
        version,
        get_chat_date(download_timestamp) as download_date
      FROM downloads
      GROUP BY version, get_chat_date(download_timestamp)
      ORDER BY download_date DESC
    `;

    return {
      success: true,
      stats,
    };
  } catch (error) {
    return { error: "Failed to fetch download statistics" };
  }
}