async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  const version = "1.2.3"; // Current APK version
  const expiryTime = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes from now
  const downloadToken = Buffer.from(crypto.randomUUID()).toString("base64");

  try {
    const [download] = await sql`
      INSERT INTO downloads 
        (version, user_agent, ip_address, completed) 
      VALUES 
        (${version}, ${session.user.email}, ${session.user.id}, false)
      RETURNING id
    `;

    const baseUrl = "https://storage.b127ai.com/releases";
    const signedUrl = `${baseUrl}/B127AI-v${version}.apk?token=${downloadToken}&expires=${expiryTime.getTime()}&downloadId=${
      download.id
    }`;

    return {
      success: true,
      downloadUrl: signedUrl,
      expiresAt: expiryTime,
      version,
    };
  } catch (error) {
    return { error: "Failed to generate download link" };
  }
}