async function handler({ content, role, type = "text", image_url = null }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  try {
    const [message] = await sql`
      INSERT INTO chat_messages (
        content,
        user_id,
        role,
        type,
        image_url,
        created_at
      ) VALUES (
        ${content},
        ${session.user.id},
        ${role},
        ${type},
        ${image_url},
        CURRENT_TIMESTAMP
      )
      RETURNING id, content, created_at, role, type, image_url
    `;

    return {
      success: true,
      message,
    };
  } catch (error) {
    return { error: "Failed to save chat message" };
  }
}