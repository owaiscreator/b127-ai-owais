async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  try {
    const messages = await sql`
      SELECT 
        id,
        content,
        role,
        type,
        image_url,
        created_at
      FROM chat_messages 
      WHERE user_id = ${session.user.id}
      ORDER BY created_at ASC
    `;

    return {
      success: true,
      messages,
    };
  } catch (error) {
    return { error: "Failed to fetch chat history" };
  }
}