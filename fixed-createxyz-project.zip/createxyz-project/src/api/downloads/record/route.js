async function handler({ version = "1.2.3", userAgent, ip }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  try {
    const result = await sql.transaction(async (sql) => {
      const [downloadRecord] = await sql`
        INSERT INTO downloads 
          (version, user_agent, ip_address, completed, user_id) 
        VALUES 
          (${version}, ${userAgent}, ${ip}, false, ${session.user.id})
        RETURNING id
      `;

      await sql`
        UPDATE downloads 
        SET completed = true 
        WHERE id = ${downloadRecord.id}
      `;

      return downloadRecord;
    });

    const downloadUrl = `https://storage.b127ai.com/releases/B127AI-v${version}.apk`;

    return {
      success: true,
      downloadUrl,
      id: result.id,
    };
  } catch (error) {
    return { error: "Failed to record download" };
  }
}