async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Authentication required" };
  }

  try {
    const downloads = await sql`
      SELECT 
        id,
        version,
        download_timestamp,
        completed,
        user_agent
      FROM downloads 
      WHERE user_id = ${session.user.id}
      ORDER BY download_timestamp DESC
    `;

    return {
      success: true,
      downloads: downloads.map((download) => ({
        id: download.id,
        version: download.version,
        timestamp: download.download_timestamp,
        completed: download.completed,
        userAgent: download.user_agent,
      })),
    };
  } catch (error) {
    return { error: "Failed to fetch download history" };
  }
}