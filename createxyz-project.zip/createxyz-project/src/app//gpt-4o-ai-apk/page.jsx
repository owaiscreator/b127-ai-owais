"use client";
import React from "react";

function MainComponent() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedImage, setSelectedImage] = useState(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const messagesEndRef = useRef(null);
  const { data: user, loading: authLoading } = useUser();
  const { signInWithGoogle, signOut } = useAuth();
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    setCheckingAuth(authLoading);
    if (user) {
      loadChatHistory();
    }
  }, [authLoading, user]);

  const loadChatHistory = async () => {
    try {
      const response = await fetch("/api/get-chat-history", {
        method: "POST",
      });
      if (!response.ok) throw new Error("Failed to load chat history");
      const data = await response.json();
      if (data.success) {
        setMessages(data.messages.reverse());
      }
    } catch (err) {
      setError("Failed to load chat history");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const isImageGeneration = inputText.startsWith("/image");
    const userMessage = {
      role: "user",
      content: inputText,
      type: isImageGeneration ? "image" : "text",
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText("");
    setIsLoading(true);
    setError("");

    try {
      await fetch("/api/save-chat-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userMessage),
      });

      if (!isImageGeneration) {
        const response = await fetch(
          "/integrations/chat-gpt/conversationgpt4",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              messages: [userMessage],
            }),
          }
        );

        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const data = await response.json();

        const botMessage = {
          role: "assistant",
          content: data.choices[0].message.content,
          type: "text",
        };

        await fetch("/api/save-chat-message", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(botMessage),
        });

        setMessages((prev) => [...prev, botMessage]);
      } else {
        const imagePrompt = inputText.slice(7).trim();
        const response = await fetch(
          `/integrations/dall-e-3/?prompt=${encodeURIComponent(imagePrompt)}`,
          {
            method: "GET",
          }
        );

        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const data = await response.json();

        const botMessage = {
          role: "assistant",
          content: imagePrompt,
          type: "image",
          image_url: data.data[0],
        };

        await fetch("/api/save-chat-message", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(botMessage),
        });

        setMessages((prev) => [...prev, botMessage]);
      }
    } catch (error) {
      console.error("Error:", error);
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-gray-50">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">B127AI</h1>
        <button
          onClick={() =>
            signInWithGoogle({ callbackUrl: "/gpt-4o-ai-apk", redirect: true })
          }
          className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">B127AI</h1>
          <button
            onClick={() =>
              signOut({ callbackUrl: "/gpt-4o-ai-apk", redirect: true })
            }
            className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            Sign out
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-8">
        <div className="bg-white rounded-lg shadow p-6 mb-8 flex flex-col h-[80vh]">
          <div className="flex-1 overflow-y-auto mb-4 space-y-4">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg px-4 py-2 ${
                    msg.role === "user"
                      ? "bg-blue-500 text-white"
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {msg.type === "image" ? (
                    <div className="space-y-2">
                      <p className="break-words">{msg.content}</p>
                      {msg.image_url && (
                        <img
                          src={msg.image_url}
                          alt={msg.content}
                          className="rounded-lg max-w-full"
                          onClick={() => setSelectedImage(msg.image_url)}
                        />
                      )}
                    </div>
                  ) : (
                    <p className="break-words">{msg.content}</p>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg px-4 py-2">
                  <div className="animate-pulse flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="relative">
            <form onSubmit={handleSubmit} className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type /image to generate images, or just chat normally..."
                className="flex-1 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                disabled={isLoading}
                onKeyPress={(e) =>
                  e.key === "Enter" && !e.shiftKey && handleSubmit(e)
                }
              />
              <button
                type="submit"
                disabled={isLoading || !inputText.trim()}
                className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 flex items-center"
              >
                {isLoading ? (
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                ) : (
                  <>
                    <i className="fas fa-paper-plane mr-2"></i>
                    {inputText.startsWith("/image") ? "Generate" : "Send"}
                  </>
                )}
              </button>
            </form>
            <div className="absolute -top-6 left-0 text-sm text-gray-500">
              Type /image followed by your description to generate images
            </div>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-red-50 text-red-600 rounded-lg">
              {error}
            </div>
          )}
        </div>
      </main>

      {selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedImage(null)}
        >
          <img
            src={selectedImage}
            alt="Full size preview"
            className="max-w-full max-h-full rounded-lg"
          />
        </div>
      )}

      <footer className="bg-white border-t">
        <div className="max-w-4xl mx-auto px-4 py-6 text-center text-gray-600">
          © {new Date().getFullYear()} B127AI. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;