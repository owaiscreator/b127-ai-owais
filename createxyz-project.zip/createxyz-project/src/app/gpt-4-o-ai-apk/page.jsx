"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [downloadCount, setDownloadCount] = useState(15427);
  const [downloads, setDownloads] = useState([]);
  const [error, setError] = useState(null);
  const [downloading, setDownloading] = useState(false);

  const features = [
    "Advanced AI Chat Capabilities",
    "Real-time Product Search & Comparison",
    "AI Image Generation",
    "Smart Shopping Assistant",
    "Offline Message Support",
    "Dark Mode Support",
    "Voice Input Support",
    "Multi-language Support",
  ];
  const requirements = [
    "Android 8.0 or higher",
    "2GB RAM minimum",
    "100MB free storage",
    "Active internet connection",
  ];
  const installSteps = [
    "Download the B127AI APK file",
    "Open Settings > Security",
    "Enable 'Install from Unknown Sources'",
    "Open the downloaded APK file",
    "Tap 'Install' when prompted",
    "Launch B127AI after installation",
  ];

  useEffect(() => {
    if (user) {
      fetch("/api/get-user-downloads", { method: "POST" })
        .then((response) => {
          if (!response.ok) throw new Error("Failed to fetch downloads");
          return response.json();
        })
        .then((data) => {
          if (data.success) {
            setDownloads(data.downloads);
          } else {
            setError(data.error);
          }
        })
        .catch((err) => {
          console.error(err);
          setError("Could not load download history");
        });
    }
  }, [user]);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch("/api/record-download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          version: "1.2.3",
          userAgent: navigator.userAgent,
          ip: "127.0.0.1",
        }),
      });

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const data = await response.json();
      if (data.success) {
        setDownloadCount((prev) => prev + 1);
        window.location.href = data.downloadUrl;
      } else {
        setError(data.error);
      }
    } catch (err) {
      console.error(err);
      setError("Download failed. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex flex-col items-center mb-12">
          <img
            src="https://ucarecdn.com/fd7cc464-dafa-4d4d-b996-dd2146c6ed3d/-/format/auto/"
            alt="B127AI Logo"
            className="w-32 h-32 mb-8 animate-pulse"
          />
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              B127AI APK Download
            </h1>
            <p className="text-yellow-400 mb-2">Version 1.2.3</p>
            <p className="text-gray-400">Last Updated: January 15, 2025</p>
          </div>
          <div className="stats flex flex-wrap justify-center gap-8 mb-8">
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-400">
                {downloadCount.toLocaleString()}
              </p>
              <p className="text-sm text-gray-400">Downloads</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-400">4.8/5</p>
              <p className="text-sm text-gray-400">Rating</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-400">45MB</p>
              <p className="text-sm text-gray-400">Size</p>
            </div>
          </div>

          {loading ? (
            <div className="text-center mb-12">
              <i className="fas fa-spinner fa-spin text-yellow-400 text-2xl"></i>
            </div>
          ) : !user ? (
            <div className="text-center mb-12">
              <p className="text-gray-400 mb-4">Sign in to download B127AI</p>
              <></>
            </div>
          ) : (
            <>
              <button
                onClick={handleDownload}
                disabled={downloading}
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-8 rounded-full shadow-lg transform transition-all hover:scale-105 flex items-center gap-2 mb-6"
              >
                <i className="fas fa-download"></i>
                {downloading ? "Downloading..." : "Download B127AI APK"}
              </button>
              {error && <p className="text-red-500 mb-6">{error}</p>}
              {downloads.length > 0 && (
                <div className="w-full bg-gray-800 p-6 rounded-xl mb-12">
                  <h2 className="text-xl font-bold mb-4 text-yellow-400">
                    Your Downloads
                  </h2>
                  <div className="space-y-2">
                    {downloads.map((download) => (
                      <div
                        key={download.id}
                        className="flex items-center justify-between text-sm"
                      >
                        <span>Version {download.version}</span>
                        <span className="text-gray-400">
                          {new Date(download.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-gray-800 p-6 rounded-xl">
            <h2 className="text-xl font-bold mb-4 text-yellow-400">
              Key Features
            </h2>
            <ul className="space-y-2">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2">
                  <i className="fas fa-check-circle text-yellow-400"></i>
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-gray-800 p-6 rounded-xl">
            <h2 className="text-xl font-bold mb-4 text-yellow-400">
              System Requirements
            </h2>
            <ul className="space-y-2">
              {requirements.map((req, index) => (
                <li key={index} className="flex items-center gap-2">
                  <i className="fas fa-microchip text-yellow-400"></i>
                  {req}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl mb-12">
          <h2 className="text-xl font-bold mb-4 text-yellow-400">
            Installation Instructions
          </h2>
          <ol className="space-y-3">
            {installSteps.map((step, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="bg-yellow-500 text-black w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0">
                  {index + 1}
                </span>
                {step}
              </li>
            ))}
          </ol>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl">
          <h2 className="text-xl font-bold mb-4 text-yellow-400">
            About B127AI
          </h2>
          <p className="text-gray-300 leading-relaxed">
            B127AI is your advanced AI companion designed to revolutionize your
            shopping and creative experience. With powerful features like
            real-time product search, price comparisons, and AI image
            generation, B127AI helps you make informed decisions and unleash
            your creativity. Our sophisticated chat system powered by advanced
            AI technology provides personalized assistance while ensuring your
            privacy and data security.
          </p>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;